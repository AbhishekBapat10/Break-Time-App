import java.util.Scanner;
class Account{
    public static int min=500;
    String name;
    int Account_num;
    public float o_Price;
    Scanner sc=new Scanner(System.in);
    public void get_info(){
        System.out.println("Enter Name");
        name=sc.nextLine();
        System.out.println("Enter Account Number");
        Account_num=sc.nextInt();
        System.out.println("Enter opening account must>500:");
        o_Price=sc.nextFloat();
        if(o_Price<500){
            System.out.println("Enter opening amount must>500");
        }
    }
    public void show(){
        System.out.println("Name:" +name);
        System.out.println("Account_number" +Account_num);
        System.out.println("Amount:" + o_Price);
    }
}
class Current extends Account{
    float deposit,withdraw,penalty;
    public void deposit(){
        System.out.println("Enter amount to deposit");
        deposit=sc.nextFloat();
        show();
        o_Price=o_Price+deposit;
        System.out.println("total amount is: " + o_Price);
    }
    public void check_Bal(){
        if(o_Price<min){
            System.out.println("Amount should be greater than 500");
            o_Price=o_Price-150;
            System.out.println("you've debited amount 150 from your account balance is:" +o_Price);
        }
    }
    public void Withdraw_Bal(){
        System.out.println("enter amount to withdraw");
        withdraw=sc.nextFloat();
        show();
        if(withdraw<o_Price){
            o_Price=o_Price-withdraw;
            System.out.println("after withdrawal balance" +o_Price);
        }
        else{
            System.out.println("insufficient balance");
        }
        check_Bal();
    }
}
class Saving extends Account{
    float deposit,withdraw,intr;
    public void deposit(){
        System.out.println("enter amount to be deposited");
        deposit=sc.nextFloat();
        show();
        o_Price=o_Price+deposit;
        System.out.println("total amount is: "+ o_Price);
    }
    public void check_interest(){
        o_Price=o_Price+intr;
        System.out.println("total amount with interest is " +o_Price);
    }
    public void Withdraw_Bal(){
        System.out.println("enter amount to withdraw");
        withdraw=sc.nextFloat();
        show();
        if(withdraw<o_Price){
            o_Price=o_Price-withdraw;
            System.out.println("after withdrawal balance:"+o_Price);
        }
        else{
            System.out.println("insufficient balance !");
        }
    }
}
public class Account2{
    static String ch;
    public static void main(String[] args) {
        int count=0;
        Scanner sc=new Scanner(System.in);
        Current cu=new Current();
        Saving sav=new Saving();
        System.out.println("Choose type of account ");
        System.out.println("Press S for savings");
        System.out.println("Press C for current");
        ch=sc.nextLine();
        if(ch.equalsIgnoreCase("c")){
            cu.get_info();
            cu.check_Bal();
            while(count!=4){
                System.out.println("1.Display\n2.Deposit\n3.Withdraw\n4.Exit");
                System.out.println("Enter your choice");
                int cho=sc.nextInt();
                switch(cho){
                    case 1: cu.show();break;
                    case 2: cu.deposit();break;
                    case 3: cu.Withdraw_Bal();break;
                    case 4: System.exit(0);break;
                    default: System.out.println("Wrong choice");
                }
            }
        }
        else if(ch.equalsIgnoreCase("s")){
            sav.get_info();
            while(count!=5){
                System.out.println("1.Display\n2.Deposit\n3.Withdraw\n4.Interest\n5.exit");
                System.out.println("Enter your choice");
                int cho=sc.nextInt();
                switch(cho){
                    case 1: sav.show();break;
                    case 2: sav.deposit();break;
                    case 3: sav.Withdraw_Bal();break;
                    case 4: sav.check_interest();break;
                    case 5: System.exit(0);break;
                    default: System.out.println("Wrong Choice !");
                }
            }
        }
        else{
            System.out.println("Wrong Choice !");
        }
    }
    
}